const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

exports.newUserSignUp = functions.auth.user().onCreate(user => {

  return admin.firestore().collection('users').doc(user.uid).set({
    email: user.email,
    manager: false,
    address: {},
  });
});

exports.userDeleted = functions.auth.user().onDelete(user => {
  const doc = admin.firestore().collection('users').doc(user.uid);
  return doc.delete();
});

exports.checkManager = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'must be logged in'
    );
  }
  const user = admin.firestore().collection('users').doc(context.auth.uid);

  const doc = await user.get();

  return doc.data().manager
})

exports.managerRoute = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'must be logged in'
    );
  }

  const user = admin.firestore().collection('users').doc(context.auth.uid);

  const doc = await user.get();

  if (doc.data().manager === false) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'not authorized'
    );
  }

  return true;
})

exports.updateStatus = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'only managers can update'
    );
  }

  const item = admin.firestore().collection('items').doc(data);
  const doc = await item.get();

  return item.update({
    inStock: !doc.data().inStock,
  });

});

exports.createOrder = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'Please sign in to order.'
    );
  }

  return admin.firestore().collection("orders").add({
    items: [...data.items],
    total: data.total,
    customer: context.auth.uid,
    completed: false,
    date: admin.firestore.FieldValue.serverTimestamp(),
  })
});

exports.completeOrder = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'Please sign in to order.'
    );
  }

  const item = admin.firestore().collection('orders').doc(data);
  const doc = await item.get()

  return item.update({
    completed: !doc.data().completed,
  });
})

exports.managerStatus = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'Please sign in to order.'
    );
  }

  const user = admin.firestore().collection('users').doc(data);
  const doc = await user.get();

  return user.update({
    manager: !doc.data().manager,
  });
})

exports.updateAccount = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'Please sign in to update account.'
    );
  }

  const user = admin.firestore().collection('users').doc(context.auth.uid);

  return user.update({
    address: {
      firstName: data.firstName,
      lastName: data.lastName,
      phoneNumber: data.phoneNumber,
      address: data.address,
      city: data.city,
      state: data.state,
      zip: data.zip,
    }
  });
})