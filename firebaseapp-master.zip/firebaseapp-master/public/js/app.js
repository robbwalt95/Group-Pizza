const loginButton = document.querySelector('#login-button');
const logoutButton = document.querySelector('#logout-button');
const inventoryLink = document.querySelector('#inventory');
const ordersLink = document.querySelector('#orders');
const usersLink = document.querySelector('#users');
const registerLink = document.querySelector('#register');
const currentUser = document.querySelector('#currentUser');;
const loginEmail = document.querySelector('#login-email');
const loginPassword = document.querySelector('#login-password');
const accountInfo = document.querySelector('#accountInfo');
const orderHistoryLink = document.querySelector('#orderHistory');


loginButton.addEventListener('click', () => {
	let email = document.querySelector('#login-email').value;
	let password = document.querySelector('#login-password').value;
	firebase
		.auth()
		.signInWithEmailAndPassword(email, password)
		.then((user) => {
			console.log('logged in', user);
		})
		.catch((error) => {
			console.log(error);
		});
	document.querySelector('#login-email').value = '';
	document.querySelector('#login-password').value = '';
});

logoutButton.addEventListener('click', () => {
	firebase.auth().signOut().then(() => console.log('signed out'));
});


//Nav Code
function myFunction() {
	var x = document.getElementById("myTopnav");
	if (x.className === "topnav") {
		x.className += " responsive";
	} else {
		x.className = "topnav";
	}
}

const checkManager = firebase.functions().httpsCallable('checkManager');
firebase.auth().onAuthStateChanged(user => {
	if (user) {
		logoutButton.style.display = 'block';
		loginButton.style.display = 'none';
		registerLink.style.display = 'none';
		currentUser.textContent = `Logged in as ${user.email}`;
		loginEmail.style.display = 'none';
		loginPassword.style.display = 'none';
		accountInfo.style.display = 'block';
		inventoryLink.style.display = 'none';
		ordersLink.style.display = 'none';
		usersLink.style.display = 'none';
		loginPassword.style.display = "none";
		orderHistoryLink.style.display = 'block';
		checkManager().then((result) => {
			if (result.data === true) {
				inventoryLink.style.display = 'block';
				ordersLink.style.display = 'block';
				usersLink.style.display = 'block';
			}
		});
	}
	else {
		logoutButton.style.display = 'none';
		loginButton.style.display = 'block';
		inventoryLink.style.display = 'none';
		ordersLink.style.display = 'none';
		registerLink.style.display = 'block';
		usersLink.style.display = 'none';
		currentUser.textContent = '';
		loginEmail.style.display = 'block';
		loginPassword.style.display = 'block';
		accountInfo.style.display = 'none';
		orderHistoryLink.style.display = 'none';
	}
});
